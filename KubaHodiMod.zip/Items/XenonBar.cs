﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.Net;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace KubaHodiMod.Items
{
    public class XenonBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Xenon Bar");
            Tooltip.SetDefault("Used for crafting Xenon Tools");
        }

        public override void SetDefaults()
        {
            item.maxStack = 999;
        }

    }
}
