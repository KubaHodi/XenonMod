﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace KubaHodiMod.Items
{
    public class XenonBow : ModItem {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Xenon Bow");
            Tooltip.SetDefault("Better than any prehardmode bow.... Trust me!");
        }

        public override void SetDefaults()
        {
            item.scale = 1.8f;
            item.ranged = true;
            item.autoReuse = true;
            item.noMelee = true;
            item.damage = 8;
            item.useAnimation = 10;
            item.useTime = 8;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.UseSound = SoundID.Item5;

            item.useAmmo = AmmoID.Arrow;
            item.shoot = 1;
            item.shootSpeed = 8f;



        }





    }




   
}
