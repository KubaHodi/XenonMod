﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace KubaHodiMod.Items
{
    public class XenonOre : ModItem
    {
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("Don't put it near water!");
            DisplayName.SetDefault("Xenon Ore");

        }
        public override void SetDefaults()
        {
            item.rare = ItemRarityID.Orange;
            item.useStyle = 1;
            item.maxStack = 999;
            item.autoReuse = true;
            item.useTurn = true;
            item.useStyle = ItemUseStyleID.SwingThrow;
            item.useTime = 10;
            item.useAnimation = 10;
            item.consumable = true;
            item.createTile = mod.TileType("XenonOre");
        }
    }
}
