﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace KubaHodiMod.Items
{
    public class XenonPickaxe : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Xenon Pickaxe");
            Tooltip.SetDefault("Light and Effective!");
        }

        public override void SetDefaults()
        {
            item.Size = new Vector2(40, 40);
            item.damage = 5;
            item.crit = 2;
            item.knockBack = 4;
            item.melee = true;
            item.pick = 50;
            item.useTime = 10;
            item.autoReuse = true;
            item.useStyle = 1;
            item.UseSound = SoundID.Item1;
            item.useAnimation = 10;
            item.rare = ItemRarityID.Blue;
            item.value = 13000;
           
        }



        public override void AddRecipes()
        {
            ModRecipe r = new ModRecipe(mod);
            r.AddIngredient(mod, "XenonBar" , 15);
            r.AddIngredient(ItemID.Wood, 8);
            r.AddTile(TileID.Anvils);
            r.SetResult(this);
            r.AddRecipe();
        }
    }
}
