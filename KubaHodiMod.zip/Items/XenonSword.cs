using Terraria.ID;
using Terraria.ModLoader;

namespace KubaHodiMod.Items
{
	public class XenonSword : ModItem
	{
		public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("Xenon Sword");

			Tooltip.SetDefault("Light and Effective!");
		}

		public override void SetDefaults() 
		{
			item.damage = 9;
			item.melee = true;
			item.width = 40;
			item.height = 40;
			item.useTime = 20;
			item.useAnimation = 10;
			item.useStyle = 1;
			item.knockBack = 6;
			item.value = 150000;
			item.rare = ItemRarityID.Blue;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
			item.scale = 1.5f;
			
		}

		public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}