using Terraria.ModLoader;
using Terraria;

namespace KubaHodiMod
{
    public class KubaHodiMod : Mod
	{

	}
    public class KubaHodiPlayer : ModPlayer 
	{
        public override void OnEnterWorld(Terraria.Player player) => Main.NewText ("[c/00FF21: Hello! and welcome in the KubaMod]");

        public override void OnRespawn(Player player) => Main.NewText("[c/fa0000: Try Again!]");

    

    }
}