﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace KubaHodiMod.Tiles
{
    public class XenonOre : ModTile
    {
        public override void SetDefaults()
        {

            Main.tileSolid[Type] = true;
            Main.tileMergeDirt[Type] = true;
            Main.tileSpelunker[Type] = true;
            Main.tileLighted[Type] = true;
            Main.tileWaterDeath[Type] = true;
            AddMapEntry(new Color(80, 200, 180));
            drop = mod.ItemType("XenonOre");
            minPick = 40;
        }

    }
}
